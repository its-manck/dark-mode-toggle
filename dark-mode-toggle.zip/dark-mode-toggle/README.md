# dark-mode-toggle
Dark mode toggle plugin for WordPress
